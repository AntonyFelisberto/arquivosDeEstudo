/*
   gera 26000 números inteiros
   MSc. Prof. Rafael S. Bressan
   2019
*/
#include <stdio.h>
#include <stdlib.h>
#define max 26000

main(){
    int i;
    FILE *arquivo;
    arquivo = fopen("numbers.txt", "w");
    if(arquivo == NULL) {
        printf("Erro na abertura do arquivo!");
        return 1;
    }
    for(i=0; i<max; i++){
        fprintf(arquivo, "%d \n", rand() % (max*2));
    }
    fclose(arquivo);
    return 0;
}



