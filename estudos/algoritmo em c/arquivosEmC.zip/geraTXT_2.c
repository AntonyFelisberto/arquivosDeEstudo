/*
   gera 26000 números inteiros
   MSc. Prof. Rafael S. Bressan
   2019
*/
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#define max 26000

main(){
    int i;
    setlocale(LC_ALL, "Portuguese");
    FILE *arquivo;
    arquivo = fopen("numbers_2.txt", "w");
    if(arquivo == NULL) {
        printf("Erro na abertura do arquivo!");
        return 1;
    }
    for(i=0; i<max; i++){
        fprintf(arquivo, "%d %d \n", rand() % (max*2), rand() % (max*2));
    }
    fclose(arquivo);
    return 0;
}



