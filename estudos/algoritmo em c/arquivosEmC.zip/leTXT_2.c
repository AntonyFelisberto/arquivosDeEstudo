/*
   Realiza a leitura de uma arquivo contendo números inteiros
   MSc. Prof. Rafael S. Bressan
   2019
*/
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

main(){
    int i, number1, number2;
    setlocale(LC_ALL, "Portuguese");
    FILE *arquivo;
    arquivo = fopen("numbers_2.txt", "r");
    if(arquivo == NULL) {
        printf("Erro na abertura do arquivo!");
        return 1;
    }
    while(fscanf(arquivo, "%d %d\n", &number1, &number2) != EOF){
          printf("%d %d\n", number1, number2);
    }
    fclose(arquivo);
    return 0;
}



