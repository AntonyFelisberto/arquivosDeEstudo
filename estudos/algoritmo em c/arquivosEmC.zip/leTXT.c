/*
   Realiza a leitura de uma arquivo contendo números inteiros
   MSc. Prof. Rafael S. Bressan
   2019
*/
#include <stdio.h>
#include <stdlib.h>
main(){
    int i=0, number, controle = 0;
    FILE *arquivo;
    arquivo = fopen("numbers.txt", "r");
    if(arquivo == NULL) {
        printf("Erro na abertura do arquivo!");
        return 1;
    }
    while(fscanf(arquivo, "%d\n", &number) != EOF){
          controle++;
    }
    fclose(arquivo);

    arquivo = fopen("numbers.txt", "r");
    if(arquivo == NULL) {
        printf("Erro na abertura do arquivo!");
        return 1;
    }
    printf("%d", controle);
    int vetor[controle];
    i = 0;
    while(fscanf(arquivo, "%d\n", &number) != EOF){
          vetor[i] = number;
          printf("%d \n", number);
          i++;
    }
    fclose(arquivo);

    for (i=0; i<controle; i++){
        printf("%d \n", vetor[i]);
    }


    return 0;
}



